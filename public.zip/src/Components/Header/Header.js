import React from 'react'
import './Header.css'
import hero from "../../Img/hero-banner.png"
import shape1 from "../../Img/shape-1.png"
import shape2 from  "../../Img/shape-2.png"
import shape3 from "../../Img/shape-3.png"

const Header = () => {
  return (
    <div className='main'>
        <div className='text'>
            <h1 className='h1'>Explore Your Travel </h1>
            <h2 className='h2'>Trusted Travel Agency </h2>
            <p className='para'>I travel not to go anywhere ,but to go. I travel for travel's sake the <br></br> great affair is to move </p>
             <div className='button'>
             <button className='btn1'>Contact Us </button>
            <button className='btn2'>Learn More </button>
             </div>
          

        </div>
        <div className='img'>
            <img className='img1' src={hero} alt='hero image'></img>
           <img className='img2' src={shape1} alt='shape1'></img>
           <img className='img3' src={shape2} alt='shape2'></img>
           <img className='img4' src={shape3} alt='shape2'></img>
           

        </div>


    </div>
  )
}

export default Header