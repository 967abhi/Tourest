import React from 'react'
import './Destination.css'
import Destination1 from "../../Img/destination-1.jpg"
import Destination2 from "../../Img/destination-2.jpg"

const Destination = () => {
  return (
    <div className='Destionationmain'>
        <div className='heading1'>
             <h1 className='desh1'>Destination</h1>   
            </div>
        <div className='heading2'>
            <h1 className='desh2'>Choose Your Place </h1></div>

         <div className='desimg'>
            <div>

           <img src={Destination1} className='desimg1'  alt='Destination image1'></img>
           <h1 className="text-overlay3">Malé</h1>
           <h1 className='text-overlay4'>Maldives</h1>
            </div>
            <div>

           <img src={Destination2}  className='desimg2' alt='Destination image 2'></img>
           <h1 className="text-overlay">Bangkok</h1>
           <h1 className='text-overlay2'> Thailand</h1>
            </div>
            
            </div>   
            

    </div>
  )
}

export default Destination;