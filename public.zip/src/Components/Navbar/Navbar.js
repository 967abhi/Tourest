import React from 'react'
import "./Navbar.css";

const Navbar = () => {
  return (
    <div className='nav'>
    <div className="header">
        <h1 className='title'>Tourest</h1>
        <ul className='list'> 
        <li className='li'>Home </li>
        <li className='li'>About Us</li>
        <li className='li'>Tours</li>
        <li className='li'>Destinations</li>
        <li className='li'>Blog</li>
        <li className='li'>Contact Us</li>

        </ul>

    </div>
    <button className='btn'>Booking Now</button>
    

    </div>
  )
}

export default Navbar