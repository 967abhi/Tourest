import Navbar from "./Components/Navbar/Navbar.js";
import './App.css'
import Header from "./Components/Header/Header.js";
import Destination from "./Components/Destination/Destination.js";


function App() {
  return (
    <div className="App">
      <Navbar/>
      <Header/>
      <Destination/>
     
    </div>
  );
}

export default App;
