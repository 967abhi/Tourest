import React from 'react'
import './Destination.css'
import Destination1 from "../../Img/destination-1.jpg"
import Destination2 from "../../Img/destination-2.jpg"
import Destination3 from "../../Img/destination-3.jpg"
import Destination4 from "../../Img/destination-4.jpg"
import Destination5 from "../../Img/destination-5.jpg"

const Destination = () => {
  return (
    <div className='Destionationmain'>
        <div className='heading1'>
             <h1 className='desh1'>Destination</h1>   
            </div>
        <div className='heading2'>
            <h1 className='desh2'>Choose Your Place </h1></div>

         <div className='desimg'>
            <div>

           <img src={Destination1} className='desimg1'  alt='Destination image1'></img>
           <h1 className="text-overlay3">Malé</h1>
           <h1 className='text-overlay4'>Maldives</h1>
            </div>
            <div>

           <img src={Destination2}  className='desimg2' alt='Destination image 2'></img>
           <h1 className="text-overlay">Bangkok</h1>
           <h1 className='text-overlay2'> Thailand</h1>
            </div>
            
            </div>  
            <div className='divdesimg2'>
                <div>
                    <img src={Destination3} className='desimg3'></img>
                    <h1 className="text-overlay5">Kuala Lumpur</h1>
           <h1 className='text-overlay6'> Malaysia</h1>

                </div>
                <div>
                    <img src={Destination4} className='desimg4'></img>
                </div>
                <div>
                    <img src={Destination5} className='desimg5'></img>
                </div>

                
                </div> 
            

    </div>
  )
}

export default Destination;