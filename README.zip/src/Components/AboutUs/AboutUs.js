import React from 'react'
import "./About.css"
import About from "../../Img/about-banner.png"
import {FaRegCompass} from "react-icons/fa"
import {BsFillBriefcaseFill} from "react-icons/bs"
import {BsUmbrellaFill} from "react-icons/bs"

const AboutUs = () => {
  return (
    <div className='Aboutusmain'>
        <div className='right'>
        <h1 className='h1'>About Us </h1>
        <h2 className='h2'>Explore all tour of the <br></br> world with us</h2>
        <p className='para'>Lorem Ipsum available, but the majority have suffered <br></br> alteration in some form, by injected humour, or randomised <br></br> words which don't look even slightly believable.</p>
        <div>
       <p className='para2'>Tour Guide</p>
       <p className='para3'> Lorem Ipsum available, but the majority <br></br> have suffered alteration in some.</p>
            <div className='firsticon'>

       <FaRegCompass className='icon1' />
            </div>
            <p className='para4'>Friendly Price</p>
       <p className='para5'> Lorem Ipsum available, but the majority <br></br> have suffered alteration in some.</p>

            <div className='firsticon2'>

<BsFillBriefcaseFill className='icon1' />
     </div>
     <p className='para6'>Reliable Tour</p>
       <p className='para7'> Lorem Ipsum available, but the majority <br></br> have suffered alteration in some.</p>

     <div className='firsticon3'>

<BsUmbrellaFill className='icon1' />
     </div>

            
     <button className='iconbtn1'>Booking Now </button>
        </div>
        </div>
        <div className='left'>
            <img src={About} alt="about image "></img>

        </div>
       


    </div>
  )
}

export default AboutUs