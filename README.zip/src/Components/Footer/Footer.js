import React from 'react'
import './Footer.css'
import {FaFacebookSquare} from "react-icons/fa"
import {CiTwitter} from "react-icons/ci"
import {BsInstagram} from "react-icons/bs"
import {AiFillLinkedin} from "react-icons/ai"
import {AiFillGoogleCircle} from "react-icons/ai"

const Footer = () => {
  return (
    <div className='Footermain'>
            <div className='Footerli1'>
                <ul className='ul1'>
                    <h1 className='ulh1'>Top Destination</h1>
                    <li className='li1'> Indonesia,Jakarta </li>
                    <li className='li1'>Maldives,Male</li>
                    <li className='li1'>Australia, Canberra</li>
                    <li className='li1'>Thailand, Bangkok</li>
                    <li className='li1'>Morocco,Rabat</li>
                </ul>
                <div className='Footerli1'>
   <ul className='ul1'>
       <h1 className='ulh1'>Categories</h1>
       <li className='li1'> Travel</li>
       <li className='li1'>Lifestyle</li>
       <li className='li1'>Fashion</li>
       <li className='li1'>Education</li>
       <li className='li1'>Food & Drink</li>
   </ul>
   <ul className='ul1'>
       <h1 className='ulh1'>Quick links</h1>
       <li className='li1'>About</li>
       <li className='li1'>Contact</li>
       <li className='li1'>Tours</li>
       <li className='li1'>Booking</li>
       <li className='li1'>Terms & Conditions</li>
   </ul>
   <ul className='ul1'>
       <h1 className='ulh1'>Gets a newsletter</h1>
       <p className='paranews'>For the latest deals and tips,travel no further than your <br/> inbox</p>
       <input type='email' placeholder='Email Address ' className='input' ></input>
       <button className='footersubscibe'>Subscribe</button>
   </ul>

</div>

            </div>

            <div className='backdown'>
                <h1>Tourist</h1>
                <p>@ 2023 codewithAbhishek .All Rights Reserved </p>
                <FaFacebookSquare/>
                <CiTwitter/>
                <BsInstagram/>
                <AiFillLinkedin/>
                <AiFillGoogleCircle/>

            </div>
      
    </div>
 
  )
}

export default Footer