import Navbar from "./Components/Navbar/Navbar.js";
import './App.css'
import Header from "./Components/Header/Header.js";
import Destination from "./Components/Destination/Destination.js";
import Footer from "./Components/Footer/Footer.js";
import AboutUs from "./Components/AboutUs/AboutUs.js";



function App() {
  return (
    <div className="App">
      <Navbar/>
      <Header/>
      <Destination/>
      <AboutUs/>
     
      <Footer/>
     
    </div>
  );
}

export default App;
